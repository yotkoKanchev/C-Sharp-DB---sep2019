﻿namespace P01.Prototype
{
    public abstract class SandwichPrototype
    {
        public abstract SandwichPrototype Clone();
    }
}
