﻿namespace ProductShop.DTO
{
    public class UserInfoDto
    {
        public int UsersCount { get; set; }

        public UserDetailsDto[] Users { get; set; }
    }
}
