﻿namespace FastFood.DataProcessor
{
    using System;
    using FastFood.Data;

    public static class Bonus
    {
	    public static string UpdatePrice(FastFoodDbContext context, string itemName, decimal newPrice)
	    {
            return null;

        }
    }
}
