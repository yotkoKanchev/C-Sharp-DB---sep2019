﻿namespace FastFood.DataProcessor
{
    using System;
    using System.IO;
    using FastFood.Data;

    public class Serializer
    {
        public static string ExportOrdersByEmployee(FastFoodDbContext context, string employeeName, string orderType)
        {
            return null;

        }

        public static string ExportCategoryStatistics(FastFoodDbContext context, string categoriesString)
        {
            return null;

        }
    }
}