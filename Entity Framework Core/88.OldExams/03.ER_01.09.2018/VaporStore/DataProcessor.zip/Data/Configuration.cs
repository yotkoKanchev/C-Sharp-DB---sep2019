﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=YOTO\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}