﻿namespace VaporStore.Data.Models.Enumerations
{
    public enum CardType
    {
        Debit = 1,
        Credit = 2,
    }
}
