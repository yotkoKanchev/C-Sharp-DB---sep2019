﻿namespace VaporStore.DataProcessor
{
    using System;
    using System.Linq;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Text;
    using Data;
    using ImportDtos;
    using Data.Models;
    using Newtonsoft.Json;
    using ValidationContext = System.ComponentModel.DataAnnotations.ValidationContext;
    using System.ComponentModel.DataAnnotations;

    public static class Deserializer
    {
        public static string ImportGames(VaporStoreDbContext context, string jsonString)
        {
            StringBuilder sb = new StringBuilder();
            var games = new List<Game>();
            var developers = new HashSet<Developer>();
            var genres = new HashSet<Genre>();
            var tags = new HashSet<Tag>();

            var gamesDto = JsonConvert.DeserializeObject<ImportGameDto[]>(jsonString);

            foreach (var gameDto in gamesDto)
            {
                bool gameDtoIsValid = gameDto.Price >= 0 &&
                    !String.IsNullOrWhiteSpace(gameDto.Name) &&
                    !String.IsNullOrWhiteSpace(gameDto.Developer) &&
                    !String.IsNullOrWhiteSpace(gameDto.Genre) &&
                    !String.IsNullOrWhiteSpace(gameDto.ReleaseDate) &&
                    gameDto.Tags.Any();

                if (gameDtoIsValid == false)
                {
                    sb.AppendLine("Invalid Data");
                    continue;
                }

                var developer = developers.Any(d => d.Name == gameDto.Developer)
                        ? developers.First(d => d.Name == gameDto.Developer)
                        : new Developer { Name = gameDto.Developer, };

                developers.Add(developer);

                var genre = genres.Any(g => g.Name == gameDto.Genre)
                        ? genres.Single(g => g.Name == gameDto.Genre)
                        : new Genre { Name = gameDto.Genre, };

                genres.Add(genre);

                var currentTags = new List<Tag>();

                foreach (var tagName in gameDto.Tags)
                {
                    var tag = tags.Any(t => t.Name == tagName)
                        ? tags.First(t => t.Name == tagName)
                        : new Tag { Name = tagName };

                    currentTags.Add(tag);
                    tags.Add(tag);
                }

                Game game = new Game
                {
                    Name = gameDto.Name,
                    Price = gameDto.Price,
                    ReleaseDate = DateTime.ParseExact(
                        gameDto.ReleaseDate, @"yyyy-MM-dd", CultureInfo.InvariantCulture),
                    Developer = developer,
                    Genre = genre,
                    GameTags = currentTags.Select(gt => new GameTag { Tag = gt }).ToList()
                };

                games.Add(game);
                sb.AppendLine($"Added {gameDto.Name} ({gameDto.Genre}) with {gameDto.Tags.Length} tags");
            }

            context.Games.AddRange(games);
            context.SaveChanges();

            return sb.ToString().TrimEnd();
            //var sb = new StringBuilder();
            //var gameDtos = JsonConvert.DeserializeObject<ImportGameDto[]>(jsonString);

            //var games = new List<Game>();
            //var genres = new List<Genre>();
            //var developers = new List<Developer>();
            //var tags = new List<Tag>();
            ////var gameTags = new List<GameTag>();

            //foreach (var gameDto in gameDtos)
            //{
            //    var dtoIsValid = IsValid(gameDto);

            //        //gameDto.Price >= 0 &&
            //        //!String.IsNullOrWhiteSpace(gameDto.Name) &&
            //        //!String.IsNullOrWhiteSpace(gameDto.Developer) &&
            //        //!String.IsNullOrWhiteSpace(gameDto.Genre) &&
            //        //!String.IsNullOrWhiteSpace(gameDto.ReleaseDate) &&
            //        //gameDto.Tags.Any();

            //    if (!dtoIsValid)
            //    {
            //        sb.AppendLine("Invalid Data");
            //        continue;
            //    }

            //    var developer = developers.FirstOrDefault(d => d.Name == gameDto.Developer);

            //    if (developer == null)
            //    {
            //        developer = new Developer
            //        {
            //            Name = gameDto.Developer
            //        };

            //        developers.Add(developer);
            //    }

            //    var genre = genres.FirstOrDefault(d => d.Name == gameDto.Genre);

            //    if (genre == null)
            //    {
            //        genre = new Genre
            //        {
            //            Name = gameDto.Genre
            //        };

            //        genres.Add(genre);
            //    }

            //    //var genre = genres.Any(g => g.Name == gameDto.Name)
            //    //    ? genres.First(g => g.Name == gameDto.Name)
            //    //    : new Genre { Name = gameDto.Genre, };

            //    //genres.Add(genre);

            //    

            //    //developers.Add(developer);

            //    var currentTags = new List<Tag>();

            //    foreach (var tagName in gameDto.Tags)
            //    {
            //        Tag tag = tags.FirstOrDefault(t => t.Name == tagName);

            //        if (tag == null)
            //        {
            //            tag = new Tag
            //            {
            //                Name = tagName
            //            };

            //            tags.Add(tag);
            //        }

            //        currentTags.Add(tag);
            //    }
            //    //foreach (var tagName in gameDto.Tags)
            //    //{
            //    //    var tag = tags.Any(t => t.Name == tagName)
            //    //        ? tags.First(t => t.Name == tagName)
            //    //        : new Tag { Name = tagName };

            //    //    currentTags.Add(tag);
            //    //    tags.Add(tag);
            //    //}

            //    var game = new Game
            //    {
            //        Name = gameDto.Name,
            //        Genre = genre,
            //        Developer = developer,
            //        Price = gameDto.Price,
            //        ReleaseDate = DateTime.ParseExact(
            //            gameDto.ReleaseDate, @"yyyy-MM-dd", CultureInfo.InvariantCulture),
            //        GameTags = currentTags.Select(gt => new GameTag { Tag = gt }).ToList()
            //    };

            //    sb.AppendLine($"{gameDto.Name} ({gameDto.Genre}) with {gameDto.Tags.Length} tags");

            //    games.Add(game);
            //}

            //context.Games.AddRange(games);
            //context.SaveChanges();

            //return sb.ToString().TrimEnd();
        }

        public static string ImportUsers(VaporStoreDbContext context, string jsonString)
        {
            return null;
        }

        public static string ImportPurchases(VaporStoreDbContext context, string xmlString)
        {
            return null;
        }

        private static bool IsValid(object dto)
        {
            var validationContext = new ValidationContext(dto);
            var validationResult = new List<ValidationResult>();

            return Validator.TryValidateObject(dto, validationContext, validationResult, true);
        }
    }
}