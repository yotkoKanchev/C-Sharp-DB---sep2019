﻿namespace FastFood.Web.ViewModels.Orders
{
    public class OrderItemViewModel
    {
        public int ItemId { get; set; }
        public string ItemName { get; set; }
    }
}
