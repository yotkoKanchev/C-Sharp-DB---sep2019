﻿namespace FastFood.Web.ViewModels.Orders
{
    public class OrderEmployeeViewModel
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }

    }
}
